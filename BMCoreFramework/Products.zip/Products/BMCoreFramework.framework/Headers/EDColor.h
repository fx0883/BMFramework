//
//  UIColor+Hex.m
//  color
//
//  Created by Andrew Sliwinski on 9/15/12.
//  Copyright (c) 2012 Andrew Sliwinski. All rights reserved.
//

#import "UIColor+Hex.h"
#import "UIColor+HSB.h"
#import "UIColor+HSL.h"
#import "UIColor+Crayola.h"
#import "UIColor+CIELAB.h"
#import "UIColor+iOS7.h"
