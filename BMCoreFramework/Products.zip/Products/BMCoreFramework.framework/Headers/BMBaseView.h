//
//  BMBaseView.h
//  BMCoreFramework
//
//  Created by fx on 14-8-19.
//  Copyright (c) 2014年 bluemobi. All rights reserved.
//

#import <UIKit/UIKit.h>
/**
 *  UIView 的子类，所有程序中使用UIView,可继承
 */
@interface BMBaseView : UIView

@end
