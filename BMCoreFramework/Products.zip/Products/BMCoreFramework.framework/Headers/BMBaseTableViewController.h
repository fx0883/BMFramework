//
//  BMBaseTableViewController.h
//  BMCoreFramework
//
//  Created by fx on 14-8-19.
//  Copyright (c) 2014年 bluemobi. All rights reserved.
//

#import <UIKit/UIKit.h>
/**
 *  UITableViewController 的子类，所有程序中使用UITableViewController,必须继承
 */
@interface BMBaseTableViewController : UITableViewController

@end
