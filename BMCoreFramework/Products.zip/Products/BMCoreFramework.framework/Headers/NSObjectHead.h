/*!
 @header NSObjectHead
 @abstract include所有NSObject的category
 @author FS (作者信息)
 @version 1.00 2014/10/12 Creation (此文档的版本信息)
 */

#ifndef BMCoreFramework_NSObjectHead_h
#define BMCoreFramework_NSObjectHead_h

#import "NSObject+BMProperty.h"
#import "NSObject+BMNotification.h"

#endif
