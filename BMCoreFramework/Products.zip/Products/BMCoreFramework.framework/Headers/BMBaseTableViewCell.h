//
//  BMBaseTableViewCell.h
//  BMCoreFramework
//
//  Created by fx on 14-8-19.
//  Copyright (c) 2014年 bluemobi. All rights reserved.
//

#import <UIKit/UIKit.h>
/**
 *  UITableViewCell 的子类，所有程序中使用UITableViewCell,可以继承
 */
@interface BMBaseTableViewCell : UITableViewCell

@end
