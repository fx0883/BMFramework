
#import <Foundation/Foundation.h>

/**
 *  @brief 程序管理器，用于管理程序初始化等等
 */
@interface BMAppManager : NSObject

@end
