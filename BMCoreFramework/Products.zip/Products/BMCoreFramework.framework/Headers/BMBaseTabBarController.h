//
//  BMBaseTabBarController.h
//  BMCoreFramework
//
//  Created by fx on 14-9-4.
//  Copyright (c) 2014年 bluemobi. All rights reserved.
//

#import <UIKit/UIKit.h>


/**
 *  UITabBarController 的子类，所有程序中使用UITabBarController,必须继承
 */
@interface BMBaseTabBarController : UITabBarController

@end
